package models;

import java.util.List;

public class Answer {

	private List<Integer> answers;

	public List<Integer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<Integer> answers) {
		this.answers = answers;
	}
	
	
}
