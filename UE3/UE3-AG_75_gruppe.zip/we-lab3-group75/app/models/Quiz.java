package models;

public class Quiz {

	private int question_selection = 10;

	public int getId() {
		return question_selection;
	}

	public void setId(int question_selection) {
		this.question_selection = question_selection;
	}
	
	
}
